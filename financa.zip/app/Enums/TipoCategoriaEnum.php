<?php

namespace App\Enums;

enum TipoCategoriaEnum: string
{
    case ENTRADA = 'entrada';
    case SAIDA = 'saida';
} 