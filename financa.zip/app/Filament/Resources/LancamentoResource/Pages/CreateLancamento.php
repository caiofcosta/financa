<?php

namespace App\Filament\Resources\LancamentoResource\Pages;

use App\Filament\Resources\LancamentoResource;
use Filament\Resources\Pages\CreateRecord;

class CreateLancamento extends CreateRecord
{
    protected static string $resource = LancamentoResource::class;
} 