<?php
    $record = $getRecord();
    $icon = $getState();
    $color = $record->categoria->cor;
?>

<div style="background-color: <?php echo e($color); ?>; width: 32px; height: 32px; border-radius: 50%; display: flex; align-items: center; justify-content: center;">
    <?php echo e(svg($icon, 'w-5 h-5 text-white')); ?>
</div> <?php /**PATH /var/www/resources/views/filament/tables/columns/icon-with-color.blade.php ENDPATH**/ ?>